Judson is a serif font designed for African literacy. It contains as many glyphs
and precomposed combinations that I know of for all African languages written in
Latin-derived alphabets.  It uses OpenType tables for correct placement of
diacritical marks, including stacked marks.  Care has been taken so that all
characters are easily distinguished, even in the italic face.  The medium roman
face also contains support for the International Phonetic Alphabet (IPA).

Currently Judson is available in roman, italic, bold and bold italic faces.

